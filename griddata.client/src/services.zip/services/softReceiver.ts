// Temporal soft-combining receiver (feedback-free HARQ for screen→camera).
//
// A single camera capture of a dense colour frame is often too noisy for the
// LDPC decoder to close — blur, glare, a hand tremor. But the sender holds each
// on-screen frame for several camera exposures, so the camera sees the SAME
// codeword two, three, many times, each a fresh independent noise draw. Summing
// their per-bit LLRs (chase combining) raises the effective SNR ~linearly in the
// number of looks: two marginal captures that each fail can together succeed.
//
// The hard part is doing this WITHOUT a back-channel and WITHOUT a pre-decode
// frame id: the receiver must recognise "this capture is the same on-screen frame
// as the one I'm accumulating" before it has decoded either. We do it by
// correlating the SIGN pattern of the soft-demod LLRs: two captures of the same
// frame agree on the vast majority of bit signs; two different frames agree on
// only ~half. When the incoming capture correlates with the accumulator we add
// it in and re-attempt the decode; when it doesn't, the on-screen frame has
// advanced, so we finalise the old accumulator and start a new one.
//
// This is the receiver side of the joint fountain↔LDPC decoder: recovered
// chunks are peeled by the FountainDecoder (cross-graph), while this stage
// squeezes every marginal frame out of the optical channel before it gets there.

import { parseFrameLdpcSoft, type ParsedFrame } from './transferCodec'

const MATCH_THRESHOLD = 0.80 // sign-agreement fraction to call two captures "same frame"
const CLAMP = 200            // cap accumulated |LLR| so a long static hold can't overflow BP

export class SoftReceiver {
  private acc: Float64Array | null = null
  private n = 0
  /** How many captures are currently combined into the live accumulator. */
  looks = 0
  /** Total captures that decoded thanks to combining ≥2 looks (telemetry). */
  combinedWins = 0

  constructor(private readonly capacity: number, private readonly rate = 0.6) {}

  /**
   * Feed one capture's per-bit LLRs (transmit order, from softDemodLLR).
   * Returns a decoded frame as soon as the live accumulator closes, else null.
   */
  feed(llr: Float64Array): ParsedFrame | null {
    if (!this.acc || this.n !== llr.length) {
      this.acc = Float64Array.from(llr)
      this.n = llr.length
      this.looks = 1
    } else if (this.agrees(llr)) {
      const a = this.acc
      for (let i = 0; i < a.length; i++) {
        let v = a[i] + llr[i]
        if (v > CLAMP) v = CLAMP; else if (v < -CLAMP) v = -CLAMP
        a[i] = v
      }
      this.looks++
    } else {
      // On-screen frame changed → start fresh on this capture.
      this.acc = Float64Array.from(llr)
      this.looks = 1
    }

    const parsed = parseFrameLdpcSoft(this.acc, this.capacity, this.rate)
    if (parsed && this.looks > 1) this.combinedWins++
    return parsed
  }

  /** Sign-agreement fraction between a new capture and the accumulator. */
  private agrees(llr: Float64Array): boolean {
    const a = this.acc!
    let agree = 0, total = 0
    // Only count bits both vectors are reasonably confident about — near-zero
    // LLRs carry no sign information and would just add coin-flips to the score.
    for (let i = 0; i < a.length; i++) {
      if (Math.abs(a[i]) < 0.5 || Math.abs(llr[i]) < 0.5) continue
      total++
      if ((a[i] < 0) === (llr[i] < 0)) agree++
    }
    if (total < a.length * 0.1) return false // too little confident overlap to judge
    return agree / total >= MATCH_THRESHOLD
  }
}
