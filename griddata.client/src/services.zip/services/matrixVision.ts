// Matrix registration for camera reading.
//
// The transmitted matrix is drawn with a WHITE quiet zone and a solid BLACK
// frame around the data grid (see layout constants below). The receiver finds
// that black frame in the camera image, so it knows exactly where the grid is
// and can sample each cell at the right pixel — instead of blindly assuming the
// matrix fills the center of the video (which never happens freehand and was
// why nothing decoded). This is the minimal "finder pattern": one border, the
// rest of the area stays data.

import type { CellReadings } from './visualCodec'

export const FRAME_RATIO = 0.07 // black frame thickness ÷ data-grid size
export const QUIET_RATIO = 0.07 // white quiet zone ÷ data-grid size
// Fraction to inset the detected outer-dark rectangle (data+frame) on each side
// to reach the data grid itself: frame / (data + 2·frame).
export const INSET_FRAC = FRAME_RATIO / (1 + 2 * FRAME_RATIO)

export interface Rect { x: number; y: number; w: number; h: number }

/**
 * Locate the data grid in the camera frame and sample every cell.
 * Returns null when the frame can't be found (nothing aligned yet).
 */
export function sampleWithRegistration(
  ctx: CanvasRenderingContext2D,
  w: number, h: number, gridW: number, gridH: number,
): CellReadings | null {
  return sampleWithRegistrationPixels(ctx.getImageData(0, 0, w, h).data, w, h, gridW, gridH)
}

/** A perspective map from the unit square to the located data grid, or null. */
export type GridMap = (u: number, v: number) => Pt

/**
 * Locate the data grid in the camera frame and return the perspective map — the
 * GRID-INDEPENDENT half of registration. The receiver can then sample this one
 * map at several candidate grid sizes (auto-detect) without re-running the
 * expensive detection per grid.
 */
export function locateMatrixPixels(px: Uint8ClampedArray, w: number, h: number): GridMap | null {
  // Downsample size for the (pure-JS, per-frame) coarse detection. 160 vs 200
  // cuts the gray-build + Otsu + flood-fill work ~35% — a real scan-rate gain on
  // phones — while the corners are still refined against the FULL-res image, so
  // registration precision is unchanged.
  const S = 160
  const sw = w >= h ? S : Math.max(1, Math.round(S * w / h))
  const sh = h > w ? S : Math.max(1, Math.round(S * h / w))
  const gray = new Float32Array(sw * sh)
  const sx = w / sw, sy = h / sh
  for (let y = 0; y < sh; y++) {
    const iy = Math.min(h - 1, (y * sy) | 0)
    for (let x = 0; x < sw; x++) {
      const ix = Math.min(w - 1, (x * sx) | 0)
      const p = (iy * w + ix) * 4
      gray[y * sw + x] = px[p] * 0.299 + px[p + 1] * 0.587 + px[p + 2] * 0.114
    }
  }
  const t = otsu(gray)
  const dark = new Uint8Array(sw * sh)
  for (let i = 0; i < gray.length; i++) dark[i] = gray[i] < t ? 1 : 0
  const box = largestRectComponent(dark, sw, sh)
  if (!box) return null
  let quad = frameCornersFast(px, w, h, dark, sw, sh, sx, sy, box, t)
  if (!quad) return null
  // Reject skewed/torn captures: the matrix is square, so a good quad has four
  // near-equal sides. A capture taken mid screen-refresh (tear) or during fast
  // motion yields a lopsided quad — drop it rather than feed a warped read to the
  // decoder (it would just fail CRC and waste a soft-combine slot anyway).
  if (!quadIsSquareEnough(quad)) return null
  // Use the top-left orientation marker to turn the geometric quad the right way
  // up (falls back to the geometric order if the marker isn't clearly seen).
  quad = orientQuad(px, w, h, quad)
  // Inset the outer dark box (data + black frame) inward to the data grid. The
  // frame is a CONSTANT pixel thickness on all four sides (the sender sizes it
  // from max(dataW,dataH)), so we must inset each side by the same pixel amount —
  // NOT by a fraction of that side's length. A proportional inset under-shoots
  // the short dimension of a rectangular matrix, leaving the map bleeding into the
  // frame (row 0 then samples black and the barcode reads nothing). We build the
  // homography over the outer quad, then step in by framePx/edgeLen per axis.
  const outer = homographyUnitSquareToQuad(quad.tl, quad.tr, quad.br, quad.bl)
  const edge = (a: Pt, b: Pt) => Math.hypot(a.x - b.x, a.y - b.y)
  const outerW = (edge(quad.tl, quad.tr) + edge(quad.bl, quad.br)) / 2
  const outerH = (edge(quad.tl, quad.bl) + edge(quad.tr, quad.br)) / 2
  const framePx = INSET_FRAC * Math.max(outerW, outerH)
  const kx = Math.min(0.45, framePx / Math.max(1, outerW))
  const ky = Math.min(0.45, framePx / Math.max(1, outerH))
  return homographyUnitSquareToQuad(
    outer(kx, ky), outer(1 - kx, ky), outer(1 - kx, 1 - ky), outer(kx, 1 - ky),
  )
}

/** Sample every cell of a `gridW`×`gridH` grid through a located map. */
export function sampleMapped(px: Uint8ClampedArray, w: number, h: number, map: GridMap, gridW: number, gridH: number): CellReadings {
  return sampleHomography(px, w, h, map, gridW, gridH)
}

/**
 * Cheap luminance-only sampling of a SINGLE grid row (default row 0). Used by the
 * barcode-first detector to probe many candidate grid widths per frame without
 * paying for a full-grid sample each time — the metadata barcode lives in row 0,
 * so this is all we need to identify the sender's spec.
 */
export function sampleRowLum(
  px: Uint8ClampedArray, w: number, h: number, map: GridMap,
  gridW: number, gridH: number, row = 0,
): Float32Array {
  const out = new Float32Array(gridW)
  const v = (row + 0.5) / gridH
  // Window ≈ ¼ cell, so each read is a small average (matches sampleHomography) —
  // a single-pixel read is far too noise-sensitive for the barcode's hard bits.
  const c0 = map(0, v), c1 = map(1, v)
  const cellPx = Math.hypot(c1.x - c0.x, c1.y - c0.y) / gridW
  const win = Math.max(0, Math.floor(cellPx / 4))
  for (let gx = 0; gx < gridW; gx++) {
    const c = map((gx + 0.5) / gridW, v)
    const cx = c.x | 0, cy = c.y | 0
    let s = 0, cnt = 0
    for (let dy = -win; dy <= win; dy++) {
      const yy = cy + dy; if (yy < 0 || yy >= h) continue
      for (let dx = -win; dx <= win; dx++) {
        const xx = cx + dx; if (xx < 0 || xx >= w) continue
        const p = (yy * w + xx) * 4
        s += px[p] * 0.299 + px[p + 1] * 0.587 + px[p + 2] * 0.114; cnt++
      }
    }
    out[gx] = cnt ? s / cnt : 0
  }
  return out
}

/**
 * Barcode-strip luminance: averages the top `rows` grid rows per column. The
 * metadata barcode is painted identically across BARCODE_ROWS rows, so averaging
 * them down a column cancels camera noise and yields a much cleaner read than a
 * single row — which is what lets the enc / gridH fields survive a shaky capture.
 */
export function sampleBarcodeLum(
  px: Uint8ClampedArray, w: number, h: number, map: GridMap,
  gridW: number, gridH: number, rows: number,
): Float32Array {
  const nr = Math.max(1, Math.min(rows, gridH))
  const out = new Float32Array(gridW)
  const c0 = map(0, 0.5 / gridH), c1 = map(1, 0.5 / gridH)
  const cellPx = Math.hypot(c1.x - c0.x, c1.y - c0.y) / gridW
  const win = Math.max(0, Math.floor(cellPx / 4))
  for (let gx = 0; gx < gridW; gx++) {
    let s = 0, cnt = 0
    for (let r = 0; r < nr; r++) {
      const c = map((gx + 0.5) / gridW, (r + 0.5) / gridH)
      const cx = c.x | 0, cy = c.y | 0
      for (let dy = -win; dy <= win; dy++) {
        const yy = cy + dy; if (yy < 0 || yy >= h) continue
        for (let dx = -win; dx <= win; dx++) {
          const xx = cx + dx; if (xx < 0 || xx >= w) continue
          const p = (yy * w + xx) * 4
          s += px[p] * 0.299 + px[p + 1] * 0.587 + px[p + 2] * 0.114; cnt++
        }
      }
    }
    out[gx] = cnt ? s / cnt : 0
  }
  return out
}

/** Canvas-free core (testable): same as sampleWithRegistration on raw pixels. */
export function sampleWithRegistrationPixels(
  px: Uint8ClampedArray,
  w: number, h: number, gridW: number, gridH: number,
): CellReadings | null {
  const map = locateMatrixPixels(px, w, h)
  return map ? sampleHomography(px, w, h, map, gridW, gridH) : null
}

interface Pt { x: number; y: number }
interface Quad { tl: Pt; tr: Pt; br: Pt; bl: Pt }

/** True if opposite sides are close enough to each other (a real rectangle). */
function quadIsSquareEnough(q: Quad): boolean {
  const d = (a: Pt, b: Pt) => Math.hypot(a.x - b.x, a.y - b.y)
  const top = d(q.tl, q.tr), right = d(q.tr, q.br), bottom = d(q.br, q.bl), left = d(q.bl, q.tl)
  const hRatio = Math.min(top, bottom) / Math.max(top, bottom)
  const vRatio = Math.min(left, right) / Math.max(left, right)
  const minSide = Math.min(top, right, bottom, left)
  return minSide > 4 && hRatio > 0.45 && vRatio > 0.45
}

/**
 * Rotate the quad so the corner carrying the white orientation marker becomes
 * top-left. Samples brightness just inside the frame ring at each corner; the
 * marker corner reads bright, the other three dark. If no corner clearly wins
 * (marker occluded / not present), the geometric order is kept — so this can
 * only help, never regress. Rotation preserves winding (never mirrors).
 */
function orientQuad(px: Uint8ClampedArray, w: number, h: number, q: Quad): Quad {
  const cx = (q.tl.x + q.tr.x + q.br.x + q.bl.x) / 4
  const cy = (q.tl.y + q.tr.y + q.br.y + q.bl.y) / 4
  const lumIn = (p: Pt): number => {
    // Sample ~8% from the outer corner toward the centre → inside the frame ring.
    const sx = p.x + (cx - p.x) * 0.08, sy = p.y + (cy - p.y) * 0.08
    let s = 0, n = 0
    for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
      const x = Math.round(sx) + dx, y = Math.round(sy) + dy
      if (x < 0 || y < 0 || x >= w || y >= h) continue
      const o = (y * w + x) * 4
      s += px[o] * 0.299 + px[o + 1] * 0.587 + px[o + 2] * 0.114; n++
    }
    return n ? s / n : 0
  }
  const corners = [q.tl, q.tr, q.br, q.bl]
  const b = corners.map(lumIn)
  let maxI = 0
  for (let i = 1; i < 4; i++) if (b[i] > b[maxI]) maxI = i
  const others = b.filter((_, i) => i !== maxI).sort((x, y) => x - y)
  const median = others[1]
  if (b[maxI] - median < 45) return q // no clear marker → keep geometric order
  const r = (i: number) => corners[(maxI + i) % 4]
  return { tl: r(0), tr: r(1), br: r(2), bl: r(3) }
}

/**
 * Corners via x±y extremes on the DOWNSAMPLED dark mask (within the located
 * component box), each then refined in a tiny full-res window. Robust for a
 * roughly-upright quad with small rotation/perspective, and ~100× cheaper than
 * a full-resolution region scan.
 */
function frameCornersFast(
  px: Uint8ClampedArray, w: number, h: number,
  dark: Uint8Array, sw: number, sh: number, sx: number, sy: number,
  box: Rect, t: number,
): Quad | null {
  const bx0 = Math.max(0, box.x - 1), by0 = Math.max(0, box.y - 1)
  const bx1 = Math.min(sw - 1, box.x + box.w + 1), by1 = Math.min(sh - 1, box.y + box.h + 1)
  let tl: Pt | null = null, tr: Pt | null = null, br: Pt | null = null, bl: Pt | null = null
  let minS = Infinity, maxS = -Infinity, minD = Infinity, maxD = -Infinity
  for (let y = by0; y <= by1; y++) {
    for (let x = bx0; x <= bx1; x++) {
      if (!dark[y * sw + x]) continue
      const s = x + y, d = x - y
      if (s < minS) { minS = s; tl = { x, y } }
      if (s > maxS) { maxS = s; br = { x, y } }
      if (d > maxD) { maxD = d; tr = { x, y } }
      if (d < minD) { minD = d; bl = { x, y } }
    }
  }
  if (!tl || !tr || !br || !bl) return null

  const win = Math.ceil(Math.max(sx, sy) * 1.6) + 2
  const lumAt = (x: number, y: number) => {
    const p = (y * w + x) * 4
    return px[p] * 0.299 + px[p + 1] * 0.587 + px[p + 2] * 0.114
  }
  // Refine a downsampled corner: minimise `score` over dark pixels in a small
  // full-res window centred on the mapped point.
  const refine = (c: Pt, score: (x: number, y: number) => number): Pt => {
    const cx = Math.round(c.x * sx), cy = Math.round(c.y * sy)
    let best: Pt = { x: cx, y: cy }, bestV = Infinity
    for (let y = Math.max(0, cy - win); y <= Math.min(h - 1, cy + win); y++) {
      for (let x = Math.max(0, cx - win); x <= Math.min(w - 1, cx + win); x++) {
        if (lumAt(x, y) >= t) continue
        const v = score(x, y)
        if (v < bestV) { bestV = v; best = { x, y } }
      }
    }
    return best
  }
  return {
    tl: refine(tl, (x, y) => x + y),
    tr: refine(tr, (x, y) => y - x),
    br: refine(br, (x, y) => -(x + y)),
    bl: refine(bl, (x, y) => x - y),
  }
}

/** Projective map from the unit square (u,v)∈[0,1]² to the given quad. */
function homographyUnitSquareToQuad(p0: Pt, p1: Pt, p2: Pt, p3: Pt): (u: number, v: number) => Pt {
  // corners for uv = (0,0),(1,0),(1,1),(0,1)  (Heckbert square→quad)
  const x0 = p0.x, x1 = p1.x, x2 = p2.x, x3 = p3.x
  const y0 = p0.y, y1 = p1.y, y2 = p2.y, y3 = p3.y
  const dx1 = x1 - x2, dx2 = x3 - x2, dx3 = x0 - x1 + x2 - x3
  const dy1 = y1 - y2, dy2 = y3 - y2, dy3 = y0 - y1 + y2 - y3
  let a: number, b: number, c: number, d: number, e: number, f: number, g: number, hh: number
  const den = dx1 * dy2 - dx2 * dy1
  if (Math.abs(dx3) < 1e-9 && Math.abs(dy3) < 1e-9) {
    a = x1 - x0; b = x2 - x1; c = x0; d = y1 - y0; e = y2 - y1; f = y0; g = 0; hh = 0
  } else {
    g = (dx3 * dy2 - dx2 * dy3) / den
    hh = (dx1 * dy3 - dx3 * dy1) / den
    a = x1 - x0 + g * x1; b = x3 - x0 + hh * x3; c = x0
    d = y1 - y0 + g * y1; e = y3 - y0 + hh * y3; f = y0
  }
  return (u, v) => {
    const wgt = g * u + hh * v + 1
    return { x: (a * u + b * v + c) / wgt, y: (d * u + e * v + f) / wgt }
  }
}

function sampleHomography(
  px: Uint8ClampedArray, w: number, h: number,
  map: (u: number, v: number) => Pt, gridW: number, gridH: number,
): CellReadings {
  const n = gridW * gridH
  const r = new Float32Array(n), g = new Float32Array(n), b = new Float32Array(n), lum = new Float32Array(n)
  const rel = new Float32Array(n)
  const c00 = map(0, 0), c10 = map(1, 0), c01 = map(0, 1)
  const cellPxW = Math.hypot(c10.x - c00.x, c10.y - c00.y) / gridW
  const cellPxH = Math.hypot(c01.x - c00.x, c01.y - c00.y) / gridH
  const cellPx = Math.min(cellPxW, cellPxH)
  const win = Math.max(0, Math.floor(cellPx / 4))
  // A crisp, well-focused cell reads nearly UNIFORM inside its sampling window;
  // a blurred cell — or one straddling a neighbour because registration drifted —
  // reads with high internal luminance variance. We turn that variance into an
  // optical reliability in [0,1] and hand it to the soft demod, so belief
  // propagation trusts sharp cells and discounts smeared ones (the optically-
  // coupled soft-decision path). Saturated windows (clipped at 0/255) also lose
  // level information → down-weighted. `relScale` normalises against a nominal
  // one-level colour step (~64 codes) so the score is encoding-independent.
  const relScale = 1 / (28 * 28)
  for (let gy = 0; gy < gridH; gy++) {
    for (let gx = 0; gx < gridW; gx++) {
      const c = map((gx + 0.5) / gridW, (gy + 0.5) / gridH)
      const cx = c.x | 0, cy = c.y | 0
      let sr = 0, sg = 0, sb = 0, cnt = 0, sl = 0, sll = 0, clip = 0
      for (let dy = -win; dy <= win; dy++) {
        const yy = cy + dy
        if (yy < 0 || yy >= h) continue
        for (let dx = -win; dx <= win; dx++) {
          const xx = cx + dx
          if (xx < 0 || xx >= w) continue
          const p = (yy * w + xx) * 4
          const rr = px[p], gg = px[p + 1], bb = px[p + 2]
          sr += rr; sg += gg; sb += bb; cnt++
          const l = rr * 0.299 + gg * 0.587 + bb * 0.114
          sl += l; sll += l * l
          if (rr <= 2 || rr >= 253 || gg <= 2 || gg >= 253 || bb <= 2 || bb >= 253) clip++
        }
      }
      const i = gy * gridW + gx
      if (cnt === 0) { r[i] = g[i] = b[i] = lum[i] = 0; rel[i] = 0; continue }
      r[i] = sr / cnt; g[i] = sg / cnt; b[i] = sb / cnt
      lum[i] = r[i] * 0.299 + g[i] * 0.587 + b[i] * 0.114
      const varL = Math.max(0, sll / cnt - (sl / cnt) * (sl / cnt))
      // sharp (low variance) → ~1; smeared → →0. Clipped windows lose a level of
      // headroom, so scale reliability down by the clipped fraction too.
      const sharp = 1 / (1 + varL * relScale)
      rel[i] = sharp * (1 - 0.5 * (clip / cnt))
    }
  }
  return { r, g, b, lum, rel }
}

/** Fallback: sample the centered region with no registration. */
export function sampleCentered(
  ctx: CanvasRenderingContext2D, w: number, h: number, gridW: number, gridH: number,
): CellReadings {
  const side = Math.min(w, h)
  const rect: Rect = { x: (w - side) / 2, y: (h - side) / 2, w: side, h: side }
  const img = ctx.getImageData(0, 0, w, h)
  return sampleRect(img.data, w, h, rect, gridW, gridH)
}

function sampleRect(px: Uint8ClampedArray, w: number, _h: number, rect: Rect, gridW: number, gridH: number): CellReadings {
  const n = gridW * gridH
  const cw = rect.w / gridW, ch = rect.h / gridH
  const win = Math.max(1, Math.floor(Math.min(cw, ch) / 4))
  const r = new Float32Array(n), g = new Float32Array(n), b = new Float32Array(n), lum = new Float32Array(n)
  for (let gy = 0; gy < gridH; gy++) {
    for (let gx = 0; gx < gridW; gx++) {
      const cx = (rect.x + (gx + 0.5) * cw) | 0
      const cy = (rect.y + (gy + 0.5) * ch) | 0
      let sr = 0, sg = 0, sb = 0, cnt = 0
      for (let dy = -win; dy <= win; dy++) {
        const yy = cy + dy
        if (yy < 0 || yy >= _h) continue
        for (let dx = -win; dx <= win; dx++) {
          const xx = cx + dx
          if (xx < 0 || xx >= w) continue
          const p = (yy * w + xx) * 4
          sr += px[p]; sg += px[p + 1]; sb += px[p + 2]; cnt++
        }
      }
      const i = gy * gridW + gx
      r[i] = sr / cnt; g[i] = sg / cnt; b[i] = sb / cnt
      lum[i] = r[i] * 0.299 + g[i] * 0.587 + b[i] * 0.114
    }
  }
  return { r, g, b, lum }
}

function otsu(gray: Float32Array): number {
  const hist = new Float64Array(256)
  for (let i = 0; i < gray.length; i++) hist[Math.min(255, Math.max(0, gray[i] | 0))]++
  const total = gray.length
  let sum = 0
  for (let i = 0; i < 256; i++) sum += i * hist[i]
  // Track the plateau of maximum between-class variance and return its center.
  // A purely bimodal image (clean black/white) has one flat max plateau spanning
  // every valid threshold; returning its center gives ~mid-gray instead of 0.
  let sumB = 0, wB = 0, best = -1, lo = -1, hi = -1
  for (let i = 0; i < 256; i++) {
    wB += hist[i]
    if (wB === 0) continue
    const wF = total - wB
    if (wF === 0) break
    sumB += i * hist[i]
    const mB = sumB / wB, mF = (sum - sumB) / wF
    const between = wB * wF * (mB - mF) * (mB - mF)
    if (between > best) { best = between; lo = hi = i }
    else if (between === best) hi = i
  }
  return lo < 0 ? 128 : (lo + hi) >> 1
}

/** Flood-fill connected components (8-conn); return the best frame candidate. */
function largestRectComponent(dark: Uint8Array, w: number, h: number): Rect | null {
  const seen = new Uint8Array(w * h)
  const stack: number[] = []
  // The transmitted matrix's black frame is wrapped by a WHITE quiet zone, so it
  // never reaches the image edge. The scene AROUND the matrix (dark desk, tablet
  // bezel, unlit room) is usually just as dark and forms one big component that
  // DOES touch the border — and its bounding box, being the whole frame, would
  // otherwise win on area and hijack registration (the map then locks onto the
  // background instead of the grid, and nothing decodes). So we score the best
  // border-touching and best interior component separately and PREFER the
  // interior one, only falling back to a border-touching region when no interior
  // candidate qualifies (e.g. the matrix is held right up to the frame edge).
  let best: Rect | null = null, bestScore = 0
  let bestEdge: Rect | null = null, bestEdgeScore = 0
  const minSide = Math.min(w, h) * 0.30

  for (let start = 0; start < dark.length; start++) {
    if (!dark[start] || seen[start]) continue
    let minX = w, minY = h, maxX = 0, maxY = 0, area = 0
    let touchesEdge = false
    stack.length = 0
    stack.push(start); seen[start] = 1
    while (stack.length) {
      const p = stack.pop()!
      const y = (p / w) | 0, x = p - y * w
      area++
      if (x < minX) minX = x; if (x > maxX) maxX = x
      if (y < minY) minY = y; if (y > maxY) maxY = y
      if (x === 0 || y === 0 || x === w - 1 || y === h - 1) touchesEdge = true
      for (let dy = -1; dy <= 1; dy++) {
        const ny = y + dy
        if (ny < 0 || ny >= h) continue
        for (let dx = -1; dx <= 1; dx++) {
          const nx = x + dx
          if (nx < 0 || nx >= w) continue
          const q = ny * w + nx
          if (dark[q] && !seen[q]) { seen[q] = 1; stack.push(q) }
        }
      }
    }
    const bw = maxX - minX + 1, bh = maxY - minY + 1
    if (bw < minSide || bh < minSide) continue
    const square = Math.min(bw, bh) / Math.max(bw, bh)
    if (square < 0.3) continue
    // The matrix tile is the largest rectangular dark region (its bbox is
    // the frame's outer edge, whether the interior is hollow or filled).
    const score = bw * bh
    if (touchesEdge) {
      if (score > bestEdgeScore) { bestEdgeScore = score; bestEdge = { x: minX, y: minY, w: bw, h: bh } }
    } else if (score > bestScore) { bestScore = score; best = { x: minX, y: minY, w: bw, h: bh } }
  }
  return best ?? bestEdge
}
