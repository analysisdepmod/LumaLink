// Off-main-thread decode pipeline with barcode-first spec detection.
//
// The heavy per-frame work — grid registration, soft colour demod + 3×3 MIMO
// un-mix, and LDPC belief propagation — runs here so the camera never stalls.
//
// BARCODE DETECTION: row 0 of the grid carries a B&W barcode encoding the
// sender's spec (enc, rate, zones, ringWidth). The receiver tries candidate
// gridW values, derives gridH from the quad's pixel aspect ratio, and reads
// row 0 with a CRC-8 check — near-instantaneous vs the old approach that ran
// full LDPC decodes per candidate.

import { locateMatrixPixels, sampleMapped, sampleBarcodeLum, type GridMap } from './matrixVision'
import { softDemodLLR, softDemodLLRZoned, capacityBytes, capacityBytesZoned, type Encoding, type EncodingSpec, type ZoneMap } from './visualCodec'
import { SoftReceiver } from './softReceiver'
import { parseFrameLdpcSoft, zoneMapFromManifest, type ParsedFrame, type TransferManifest } from './transferCodec'
import { buildZoneMap, isMultiZone } from './adaptiveZones'
import { setBpDecoder } from './ldpc'
import { loadLdpcWasm } from './ldpcWasm'
import { decodeBarcodeRow, BARCODE_ROWS } from './metaBarcode'

let wasmActive = false
loadLdpcWasm().then(w => { if (w) { setBpDecoder((code, llr, iters) => w.decode(code, llr, iters)); wasmActive = true } }).catch(() => {})

interface DecodeRequest {
  pixels?: ArrayBuffer
  bitmap?: ImageBitmap
  w: number
  h: number
  auto: boolean
  spec?: EncodingSpec
  manifest?: TransferManifest
  reset?: boolean
  id: number
}
interface DecodeReply {
  id: number
  result: ParsedFrame | null
  found: boolean
  looks: number
  combinedWins: number
  lockedSpec?: EncodingSpec
  ms: number
  wasm: boolean
  dark: boolean
}

// Candidate gridW values for barcode-first detection. The sender derives its grid
// from its own screen (any multiple of 8), so the receiver cannot assume a fixed
// size — it enumerates ALL plausible multiples of 8 and, for each, samples ONLY
// row 0 (cheap) and checks the metadata barcode's CRC. gridH is derived from the
// quad's pixel aspect ratio. Row-0 probing is so light we can try every width per
// frame, so an arbitrary rectangular grid still locks in a single good capture.
const GRID_WIDTHS: number[] = []
for (let w = 40; w <= 240; w += 8) GRID_WIDTHS.push(w)
// Covers the largest sender presets (e.g. 320×176 ≈ 56k). The barcode probe only
// samples BARCODE_ROWS rows so it's cheap even for big candidates; the exact gridH
// from the barcode then bounds the one full decode we run on the winning width.
const MAX_DETECT_CELLS = 65000

// LDPC fallback candidates (for senders without barcode or when barcode fails)
const ENCS: Encoding[] = ['color64', 'color32', 'color16', 'color8', 'bw']
const GRID_DIMS: { w: number; h: number }[] = [
  { w: 96, h: 96 }, { w: 64, h: 64 }, { w: 32, h: 32 },
  { w: 160, h: 160 }, { w: 128, h: 128 }, { w: 16, h: 16 },
  { w: 160, h: 88 }, { w: 120, h: 64 }, { w: 192, h: 104 },
  { w: 88, h: 160 }, { w: 104, h: 192 }, { w: 48, h: 80 },
  { w: 160, h: 96 }, { w: 96, h: 160 },
]
const RATES = [0.6, 0.75]
const CANDIDATES: EncodingSpec[] = []
for (const rate of RATES) for (const enc of ENCS) for (const g of GRID_DIMS) CANDIDATES.push({ enc, gridW: g.w, gridH: g.h, rate })
const FALLBACK_BUDGET = 3

function deriveGridH(map: GridMap, gridW: number): number {
  const tl = map(0, 0), tr = map(1, 0), bl = map(0, 1), br = map(1, 1)
  const pw = (Math.hypot(tr.x - tl.x, tr.y - tl.y) + Math.hypot(br.x - bl.x, br.y - bl.y)) / 2
  const ph = (Math.hypot(bl.x - tl.x, bl.y - tl.y) + Math.hypot(br.x - tr.x, br.y - tr.y)) / 2
  const cellPx = pw / gridW
  return Math.max(BARCODE_ROWS + 1, Math.round(ph / cellPx))
}

let rx: SoftReceiver | null = null
let locked: EncodingSpec | null = null
let lockedZm: ZoneMap | null = null
let fCursor = 0
// Barcode lock needs one confirmation: sync+CRC give ~16 bits of validation, but
// across every width/phase/offset probed each frame a stray match is still
// possible. Requiring the SAME (enc,gridW,gridH) barcode on two frames — unless a
// full LDPC decode already vouched for it — makes a false lock essentially
// impossible while a real barcode (100% read under realistic blur) confirms in 2 frames.
let pendingKey = ''
let pendingCount = 0
// Self-healing: if a lock is wrong (bad barcode read that slipped confirmation),
// every subsequent frame fails to decode. After this many consecutive locked
// frames with zero successful decodes, drop the lock and re-search from scratch.
let sinceProgress = 0
const RELOCK_AFTER = 45

let offCanvas: OffscreenCanvas | null = null
let offCtx: OffscreenCanvasRenderingContext2D | null = null

let t0 = 0
let curDark = false
self.onmessage = (e: MessageEvent<DecodeRequest>) => {
  const { pixels, bitmap, w, h, auto, spec, manifest, reset, id } = e.data
  t0 = performance.now()
  try {
    if (reset) { locked = null; lockedZm = null; rx = null; fCursor = 0; pendingKey = ''; pendingCount = 0; sinceProgress = 0 }
    if (manifest && !lockedZm) lockedZm = zoneMapFromManifest(manifest)

    let px: Uint8ClampedArray
    if (bitmap) {
      if (!offCanvas || offCanvas.width !== w || offCanvas.height !== h) {
        offCanvas = new OffscreenCanvas(w, h)
        offCtx = offCanvas.getContext('2d', { willReadFrequently: true })
      }
      offCtx!.drawImage(bitmap, 0, 0, w, h)
      px = offCtx!.getImageData(0, 0, w, h).data
      bitmap.close()
    } else {
      px = new Uint8ClampedArray(pixels!)
    }
    { let s = 0, c = 0; const b = ((h >> 1) * w + (w >> 1)) * 4; for (let i = -32; i <= 32; i += 4) { const p = b + i * 4; s += px[p] * 0.299 + px[p + 1] * 0.587 + px[p + 2] * 0.114; c++ } curDark = s / c < 6 }
    const map = locateMatrixPixels(px, w, h)
    if (!map) { reply({ id, result: null, found: false, looks: 0, combinedWins: 0 }); return }

    const known = auto ? locked : (spec ?? null)
    if (known) {
      const cap = lockedZm ? capacityBytesZoned(lockedZm) : capacityBytes(known)
      if (!rx) rx = new SoftReceiver(cap, known.rate ?? 0.6)
      const readings = sampleMapped(px, w, h, map, known.gridW, known.gridH)
      const llr = lockedZm ? softDemodLLRZoned(readings, lockedZm) : softDemodLLR(readings, known)
      const result = rx.feed(llr)
      // Auto-relock (auto mode only): a correct lock decodes frames; a wrong one
      // never does. Drop it after a long dry spell so detection can start over.
      if (auto) {
        if (result) sinceProgress = 0
        else if (++sinceProgress >= RELOCK_AFTER) {
          locked = null; lockedZm = null; rx = null; sinceProgress = 0
          pendingKey = ''; pendingCount = 0
          reply({ id, result: null, found: false, looks: 0, combinedWins: 0 })
          return
        }
      }
      reply({ id, result, found: true, looks: rx.looks, combinedWins: rx.combinedWins })
      return
    }

    // ── Barcode-first detection ──
    // Probe EVERY candidate width with a cheap row-0-only sample and check the
    // metadata barcode. Deriving gridH from geometry means any rectangular grid
    // the sender chose is found without guessing its height. The first width
    // whose barcode CRC passes wins.
    let hit: { spec: EncodingSpec; zm: ZoneMap | null } | null = null
    for (const gw of GRID_WIDTHS) {
      const ghApprox = deriveGridH(map, gw)
      if (gw * ghApprox > MAX_DETECT_CELLS) continue
      try {
        // Read the barcode STRIP (all BARCODE_ROWS rows averaged) at the geometry-
        // derived height — good enough to place row 0, since it's at the very top.
        const rowLum = sampleBarcodeLum(px, w, h, map, gw, ghApprox, BARCODE_ROWS)
        const bc = decodeBarcodeRow(rowLum, gw)
        if (!bc) continue
        // The barcode carries the EXACT gridH; geometry only approximated it.
        // Cross-check them: a genuine barcode's height agrees with the pixel
        // geometry, so a wild mismatch means a stray CRC match at the wrong
        // width — reject it. This is what kills the "read 8 as 64" false locks.
        const gh = (bc.gridH >= 8 && gw * bc.gridH <= MAX_DETECT_CELLS) ? bc.gridH : ghApprox
        const ratio = gh / Math.max(1, ghApprox)
        if (ratio < 0.6 || ratio > 1.7) continue
        const s: EncodingSpec = { enc: bc.enc, gridW: gw, gridH: gh, rate: bc.rate }
        const zm = (bc.zones && bc.enc !== 'bw') ? buildZoneMap(gw, gh, bc.enc, bc.ringWidth) : null
        hit = { spec: s, zm }
        break
      } catch { /* sample error — skip this width */ }
    }
    if (hit) {
      const { spec: s, zm } = hit
      const key = `${s.enc}:${s.gridW}:${s.gridH}:${zm ? 'z' : ''}`
      try {
        const cap = zm ? capacityBytesZoned(zm) : capacityBytes(s)
        const readings = sampleMapped(px, w, h, map, s.gridW, s.gridH)
        const llr = zm ? softDemodLLRZoned(readings, zm) : softDemodLLR(readings, s)
        const parsed = parseFrameLdpcSoft(llr, cap, s.rate, true)
        if (parsed) {
          // Full frame decoded → spec is certainly correct: lock immediately.
          locked = s; lockedZm = zm; rx = new SoftReceiver(cap, s.rate)
          pendingKey = ''; pendingCount = 0
          reply({ id, result: parsed, found: true, looks: 1, combinedWins: 0, lockedSpec: s })
          return
        }
        // Barcode CRC passed but the frame didn't decode yet (blur/motion). Lock
        // only after a second frame reports the same spec, to rule out a fluke.
        if (key === pendingKey) {
          pendingCount++
          if (pendingCount >= 2) {
            locked = s; lockedZm = zm; rx = new SoftReceiver(cap, s.rate)
            reply({ id, result: null, found: true, looks: 1, combinedWins: 0, lockedSpec: s })
            return
          }
        } else { pendingKey = key; pendingCount = 1 }
        reply({ id, result: null, found: true, looks: 0, combinedWins: 0 })
        return
      } catch { /* sample error — fall through to LDPC search */ }
    }

    // LDPC fallback: try full decode on a few candidates (for senders without barcode)
    for (let n = 0; n < FALLBACK_BUDGET; n++) {
      const cand = CANDIDATES[(fCursor + n) % CANDIDATES.length]
      if (cand.gridW * cand.gridH > MAX_DETECT_CELLS) continue
      try {
        const readings = sampleMapped(px, w, h, map, cand.gridW, cand.gridH)
        const cap = capacityBytes(cand)
        const parsed = parseFrameLdpcSoft(softDemodLLR(readings, cand), cap, cand.rate, true)
        if (parsed) {
          locked = cand; lockedZm = null
          rx = new SoftReceiver(cap, cand.rate)
          reply({ id, result: parsed, found: true, looks: 1, combinedWins: 0, lockedSpec: cand })
          return
        }
        if (cand.enc !== 'bw' && cand.gridW * cand.gridH <= 20000) {
          const zm = buildZoneMap(cand.gridW, cand.gridH, cand.enc)
          if (isMultiZone(zm)) {
            const zcap = capacityBytesZoned(zm)
            const zparsed = parseFrameLdpcSoft(softDemodLLRZoned(readings, zm), zcap, cand.rate, true)
            if (zparsed) {
              locked = cand; lockedZm = zm
              rx = new SoftReceiver(zcap, cand.rate)
              reply({ id, result: zparsed, found: true, looks: 1, combinedWins: 0, lockedSpec: cand })
              return
            }
          }
        }
      } catch { /* OOM — skip */ }
    }
    fCursor = (fCursor + FALLBACK_BUDGET) % CANDIDATES.length
    reply({ id, result: null, found: true, looks: 0, combinedWins: 0 })
  } catch {
    reply({ id, result: null, found: false, looks: 0, combinedWins: 0 })
  }
}

function reply(r: Omit<DecodeReply, 'ms' | 'wasm' | 'dark'>) {
  ;(self as unknown as Worker).postMessage({ ...r, ms: performance.now() - t0, wasm: wasmActive, dark: curDark })
}

export type { DecodeRequest, DecodeReply }
