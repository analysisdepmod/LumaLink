// Self-contained visual-transfer codec (runs entirely in the browser).
//
// Pipeline (sender):   bytes → deflate → K fixed chunks → systematic fountain
//                      → pack [type|seed|len|payload|crc] → LDPC codeword
//                      → interleave → colour grid → screen
// Pipeline (receiver): camera grid → optical soft-demod (per-bit LLR, weighted
//                      by each cell's optical reliability) → de-interleave
//                      → temporal soft-combine per seed → LDPC belief-propagation
//                      → CRC → fountain peel → inflate → file/text
//
// Frames are rateless (fountain / LT codes): the receiver only needs *any*
// ~K distinct frames to rebuild the data, which is what makes "resume" and
// noise tolerance work — a dropped or corrupted frame is simply ignored and
// the next good one carries the transfer forward.
//
// ── ECC: LDPC only ──
// The inner code is a soft-decision IRA-LDPC decoded with belief propagation on
// per-bit LLRs coming straight from the optical demod. Reed-Solomon (hard
// symbol decisions) and Hadamard spreading were removed: they discard the
// per-cell confidence the camera actually gives us, which is exactly the
// information the joint soft decoder needs. See ldpc.ts / wht.ts.

import { crc32 } from './crc32'
import { compress, decompress } from './compress'
import { indicesForSeed } from './fountainDecoder'
import { capacityBytes, capacityBytesZoned, bytesToBits, bitsToBytes, specRate, DEFAULT_RATE, type Encoding, type EncodingSpec, type ZoneMap } from './visualCodec'
import { deserializeZoneMap, serializeZoneMap } from './adaptiveZones'
import { makeLdpcKM, ldpcEncodeParity, ldpcDecode, type LdpcCode } from './ldpc'

const MANIFEST_SUBHEADER = 2 // [partIndex, partCount] prefix on manifest payloads

export const HEADER_BYTES = 9   // type(1) + seed(4) + len(4)
export const CRC_BYTES = 4
export const FRAME_TYPE_MANIFEST = 0
export const FRAME_TYPE_DATA = 1
export const FRAME_TYPE_SOLO = 2 // whole transfer in one static frame

export interface TransferManifest {
  v: 1
  id: number            // random id — receiver detects a new transfer by this
  kind: 'file' | 'text'
  name: string          // filename ('' for text)
  mime: string          // MIME type
  total: number         // original (uncompressed) byte length
  comp: number          // compressed byte length
  k: number             // number of chunks
  chunk: number         // chunk size in bytes
  enc: Encoding         // visual encoding
  gridW: number         // grid columns
  gridH: number         // grid rows
  rate: number          // LDPC code rate used for this transfer's frames
  zones?: [number, number] // adaptive spatial coding: [ringWidth, centerEncIndex]
}

export interface BuildOptions {
  spec: EncodingSpec
  chunkSize: number         // payload bytes per data frame (≤ maxPayload)
  frameCount: number        // number of fountain data frames to emit
  manifestEvery?: number    // re-insert a manifest every N data frames (default 8)
  zoneMap?: ZoneMap          // adaptive spatial coding zone map
  zoneRingWidth?: number     // ring width used to build the zone map (for manifest)
}

export interface BuiltTransfer {
  frames: Uint8Array[]      // ordered frames the matrix cycles through
  manifest: TransferManifest
  capacity: number          // bytes per frame (full grid capacity)
  dataFrameCount: number
  static: boolean           // true = one self-contained frame, no animation
}

export interface SoloContent {
  kind: 'file' | 'text'
  name: string
  mime: string
  bytes: Uint8Array         // reconstructed original bytes
}

/** Message-data bytes a full frame carries before header/CRC. */
export function frameDataBytes(spec: EncodingSpec, zm?: ZoneMap): number {
  const cap = zm ? capacityBytesZoned(zm) : capacityBytes(spec)
  return ldpcMessageBytes(cap, specRate(spec))
}

/** Largest usable payload (chunk) for an encoding spec. */
export function maxPayload(spec: EncodingSpec, zm?: ZoneMap): number {
  return frameDataBytes(spec, zm) - HEADER_BYTES - CRC_BYTES
}

/** Rebuild the EncodingSpec a manifest describes. */
export function specFromManifest(m: TransferManifest): EncodingSpec {
  return { enc: m.enc, gridW: m.gridW, gridH: m.gridH, rate: m.rate }
}

/** Rebuild the zone map from a manifest, if zones are present. */
export function zoneMapFromManifest(m: TransferManifest): ZoneMap | null {
  if (!m.zones) return null
  return deserializeZoneMap(m.gridW, m.gridH, m.zones)
}

// ── Interleaving ──
// A blur smear or glare spot corrupts a CONTIGUOUS patch of cells → a burst of
// bad bits. LDPC belief propagation degrades if many wired bits of one check
// fail together, so we transmit the codeword bytes in a scrambled order: any
// contiguous on-screen burst is spread across the whole Tanner graph, leaving
// each parity check only a few unreliable bits it can still resolve from its
// neighbours. The permutation depends only on `capacity`
// (a Fisher-Yates shuffle seeded by it), so sender and receiver derive the same
// one without any side-channel — even the very first manifest frame de-scrambles.
const permCache = new Map<number, Uint32Array>()
function framePermutation(capacity: number): Uint32Array {
  const cached = permCache.get(capacity)
  if (cached) return cached
  const p = new Uint32Array(capacity)
  for (let i = 0; i < capacity; i++) p[i] = i
  let s = (capacity ^ 0x9e3779b9) >>> 0
  const rnd = () => { // mulberry32
    s = (s + 0x6d2b79f5) >>> 0
    let t = Math.imul(s ^ (s >>> 15), 1 | s)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
  for (let i = capacity - 1; i > 0; i--) { const j = (rnd() * (i + 1)) | 0; const tmp = p[i]; p[i] = p[j]; p[j] = tmp }
  permCache.set(capacity, p)
  return p
}
/** Scramble frame bytes for transmission: out[i] = frame[perm[i]]. */
function interleave(frame: Uint8Array): Uint8Array {
  const perm = framePermutation(frame.length)
  const out = new Uint8Array(frame.length)
  for (let i = 0; i < frame.length; i++) out[i] = frame[perm[i]]
  return out
}

// ── Codeword whitening (anti-flicker) ──
// A manifest frame carries a small, zero-padded payload, so its LDPC codeword is
// mostly zeros → mapped to cells it renders noticeably DARKER than the busy data
// frames. Cycling data→manifest→data every N frames then reads as a periodic
// FLICKER on screen. We XOR every codeword with a fixed pseudo-random ±mask
// before it hits the cells, so EVERY frame — whatever its payload — has a
// balanced, uniform brightness/colour distribution and the flicker disappears.
// The mask depends only on the bit length (sender and receiver derive the same
// one), and the receiver undoes it at the LLR level by flipping the sign of the
// masked bits before LDPC decoding.
const whiteCache = new Map<number, Uint8Array>()
function frameWhiteMask(nbits: number): Uint8Array {
  const cached = whiteCache.get(nbits)
  if (cached) return cached
  const w = new Uint8Array(nbits)
  let s = (nbits ^ 0x5bd1e995) >>> 0
  for (let i = 0; i < nbits; i++) {
    s = (s + 0x6d2b79f5) >>> 0
    let t = Math.imul(s ^ (s >>> 15), 1 | s)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    w[i] = ((t ^ (t >>> 14)) >>> 0) & 1
  }
  whiteCache.set(nbits, w)
  return w
}

// ── LDPC soft-decision frame codec ──
// The frame footprint is `capacity` bytes → cells. The ECC is an LDPC codeword
// decoded with SOFT per-bit LLRs from the colour demod. On a noisy
// colour read this recovers frames the hard RS path drops. Only for the
// calibrated multi-level colour encodings (they expose clean soft info).
const ldpcCodeCache = new Map<string, LdpcCode>()
/** Message BYTES carried by an LDPC frame of `capacity` codeword bytes at `rate`. */
export function ldpcMessageBytes(capacity: number, rate: number = DEFAULT_RATE): number {
  return Math.max(HEADER_BYTES + CRC_BYTES + 1, Math.floor(capacity * rate))
}
function ldpcCodeFor(capacity: number, rate: number = DEFAULT_RATE): LdpcCode {
  const key = capacity + ':' + rate
  const cached = ldpcCodeCache.get(key)
  if (cached) return cached
  const k = ldpcMessageBytes(capacity, rate) * 8 // message bits
  const m = capacity * 8 - k                      // parity bits (fills the frame)
  const code = makeLdpcKM(k, m, 3)
  ldpcCodeCache.set(key, code)
  return code
}

export function packFrameLdpc(type: number, seed: number, payload: Uint8Array, capacity: number, rate: number = DEFAULT_RATE): Uint8Array {
  const M = ldpcMessageBytes(capacity, rate)
  const msg = new Uint8Array(M)
  const dv = new DataView(msg.buffer)
  const usable = M - HEADER_BYTES - CRC_BYTES
  const len = Math.min(payload.length, usable)
  msg[0] = type
  dv.setUint32(1, seed >>> 0, true)
  dv.setUint32(5, len, true)
  msg.set(payload.subarray(0, len), HEADER_BYTES)
  dv.setUint32(M - CRC_BYTES, crc32(msg, 0, M - CRC_BYTES), true)
  const code = ldpcCodeFor(capacity, rate)
  const msgBits = bytesToBits(msg)                 // k bits
  const parity = ldpcEncodeParity(code, msgBits)   // m bits
  const cw = new Uint8Array(code.n)
  cw.set(msgBits, 0); cw.set(parity, code.k)        // [message | parity]
  const mask = frameWhiteMask(code.n)               // balance brightness (anti-flicker)
  for (let i = 0; i < code.n; i++) cw[i] ^= mask[i]
  return interleave(bitsToBytes(cw))                // n bits = capacity bytes
}

/** Undo the byte-interleave at the LLR level (each byte = 8 consecutive LLRs). */
function deinterleaveLLR(llr: Float64Array, capacity: number): Float64Array {
  const perm = framePermutation(capacity)
  const out = new Float64Array(capacity * 8)
  for (let i = 0; i < capacity; i++) {
    const src = i * 8, dst = perm[i] * 8
    for (let b = 0; b < 8; b++) out[dst + b] = llr[src + b]
  }
  return out
}

/**
 * Soft parse: `llr` holds per-frame-bit LLRs (LLR>0 favours bit 0) in transmitted
 * order (from softDemodLLR). De-interleaves, LDPC-decodes, validates CRC. Null if
 * unrecoverable.
 */
export function parseFrameLdpcSoft(llr: Float64Array, capacity: number, rate: number = DEFAULT_RATE, fastOnly = false): ParsedFrame | null {
  if (llr.length < capacity * 8) return null
  const code = ldpcCodeFor(capacity, rate)
  const cwLlr = deinterleaveLLR(llr, capacity)      // [message | parity] order
  // Undo codeword whitening: a masked bit was flipped, so its LLR sign flips.
  const mask = frameWhiteMask(code.n)
  for (let i = 0; i < code.n; i++) if (mask[i]) cwLlr[i] = -cwLlr[i]
  const M = ldpcMessageBytes(capacity, rate)

  const check = (msgBits: Uint8Array): ParsedFrame | null => {
    const msg = bitsToBytes(msgBits).subarray(0, M)
    const dv = new DataView(msg.buffer, msg.byteOffset, msg.byteLength)
    if (dv.getUint32(M - CRC_BYTES, true) !== crc32(msg, 0, M - CRC_BYTES)) return null
    const type = msg[0]
    const seed = dv.getUint32(1, true)
    const len = dv.getUint32(5, true)
    if (len > M - HEADER_BYTES - CRC_BYTES) return null
    return { type, seed, payload: msg.slice(HEADER_BYTES, HEADER_BYTES + len) }
  }

  // FAST PATH: the code is systematic (message bits are the first k codeword bits),
  // so take a hard decision on them and test the CRC directly. On a clean read this
  // passes immediately and we SKIP the expensive belief-propagation entirely —
  // restoring RS-like scan speed for easy modes (bw/color8). Only genuinely noisy
  // frames fall through to the full soft decoder below.
  const hard = new Uint8Array(code.k)
  for (let i = 0; i < code.k; i++) hard[i] = cwLlr[i] < 0 ? 1 : 0
  const fast = check(hard)
  if (fast) return fast

  // `fastOnly` is used by the auto-detect SEARCH: it tries many wrong candidate
  // specs per capture, and every wrong one fails the CRC here — running full BP on
  // each (especially on dense grids) would freeze the worker. So during search we
  // reject on the fast path alone; the real per-frame decode (locked spec) keeps BP.
  if (fastOnly) return null

  // SLOW PATH: soft belief-propagation actually corrects the errors. 24 iters
  // (was 40) keeps most of the correction while cutting per-frame time — a frame
  // too marginal to close in 24 iters usually closes on the NEXT capture once the
  // temporal soft-combiner has added its LLRs, so fewer iters ⇒ higher scan rate
  // for roughly the same end-to-end success.
  return check(ldpcDecode(code, cwLlr, 24))
}

/** Pack one frame: [type|seed|len|payload|crc] → LDPC codeword → interleave. */
function packFrame(type: number, seed: number, payload: Uint8Array, capacity: number, rate: number): Uint8Array {
  return packFrameLdpc(type, seed, payload, capacity, rate)
}

export interface ParsedFrame {
  type: number
  seed: number
  payload: Uint8Array
}

/** Split compressed data into K fixed-size, zero-padded chunks. */
export function makeChunks(data: Uint8Array, chunkSize: number): Uint8Array[] {
  const k = Math.max(1, Math.ceil(data.length / chunkSize))
  const chunks: Uint8Array[] = []
  for (let i = 0; i < k; i++) {
    const c = new Uint8Array(chunkSize)
    c.set(data.subarray(i * chunkSize, (i + 1) * chunkSize))
    chunks.push(c)
  }
  return chunks
}

/** XOR the fountain-selected chunks for a seed into one coded chunk. */
export function fountainEncode(chunks: Uint8Array[], seed: number, chunkSize: number): Uint8Array {
  const out = new Uint8Array(chunkSize)
  for (const idx of indicesForSeed(seed, chunks.length)) {
    const c = chunks[idx]
    for (let i = 0; i < chunkSize; i++) out[i] ^= c[i]
  }
  return out
}

const textEncoder = new TextEncoder()
const textDecoder = new TextDecoder()

/**
 * Encode a manifest as one or more type-0 frames. The manifest JSON is
 * deflated (small filenames/mime can still overflow a tiny grid) and split
 * into parts, each prefixed with [partIndex, partCount] so the receiver can
 * reassemble it regardless of grid size.
 */
export function encodeManifestFrames(m: TransferManifest, capacity: number): Uint8Array[] {
  const rate = m.rate ?? DEFAULT_RATE // manifest frames ride the transfer's own rate
  const body = compress(textEncoder.encode(JSON.stringify(m)))
  const dataBytes = ldpcMessageBytes(capacity, rate)
  const usable = dataBytes - HEADER_BYTES - CRC_BYTES - MANIFEST_SUBHEADER
  const parts = Math.max(1, Math.ceil(body.length / usable))
  const frames: Uint8Array[] = []
  for (let p = 0; p < parts; p++) {
    const slice = body.subarray(p * usable, (p + 1) * usable)
    const payload = new Uint8Array(MANIFEST_SUBHEADER + slice.length)
    payload[0] = p
    payload[1] = parts
    payload.set(slice, MANIFEST_SUBHEADER)
    frames.push(packFrame(FRAME_TYPE_MANIFEST, 0, payload, capacity, rate))
  }
  return frames
}

/** Reassembles multi-part manifests from type-0 frame payloads. */
export class ManifestAssembler {
  private parts = new Map<number, Uint8Array>()
  private count = 0

  /** Feed a manifest-frame payload; returns the manifest once complete. */
  add(payload: Uint8Array): TransferManifest | null {
    if (payload.length < MANIFEST_SUBHEADER) return null
    const idx = payload[0], total = payload[1]
    if (total < 1) return null
    if (total !== this.count) { this.parts.clear(); this.count = total }
    this.parts.set(idx, payload.slice(MANIFEST_SUBHEADER))
    if (this.parts.size !== this.count) return null
    let len = 0
    for (let i = 0; i < this.count; i++) {
      const part = this.parts.get(i)
      if (!part) return null
      len += part.length
    }
    const body = new Uint8Array(len)
    let off = 0
    for (let i = 0; i < this.count; i++) { const part = this.parts.get(i)!; body.set(part, off); off += part.length }
    try {
      return JSON.parse(textDecoder.decode(decompress(body))) as TransferManifest
    } catch {
      return null
    }
  }
}

/**
 * Try to pack the whole transfer into ONE self-contained frame. Returns the
 * frame if everything fits (short text, tiny image → a single static matrix,
 * like a QR code — no animation needed), otherwise null.
 * Solo payload: [metaLen u16][meta JSON][compressed data].
 */
export function buildSolo(
  raw: Uint8Array,
  meta: { kind: 'file' | 'text'; name: string; mime: string },
  spec: EncodingSpec,
  comp?: Uint8Array,
  zm?: ZoneMap,
): Uint8Array | null {
  const capacity = zm ? capacityBytesZoned(zm) : capacityBytes(spec)
  const usable = frameDataBytes(spec, zm) - HEADER_BYTES - CRC_BYTES
  const body = comp ?? compress(raw)
  const metaJson = textEncoder.encode(JSON.stringify(meta))
  const total = 2 + metaJson.length + body.length
  if (total > usable) return null
  const payload = new Uint8Array(total)
  new DataView(payload.buffer).setUint16(0, metaJson.length, true)
  payload.set(metaJson, 2)
  payload.set(body, 2 + metaJson.length)
  return packFrame(FRAME_TYPE_SOLO, 0, payload, capacity, specRate(spec))
}

/** Decode a solo-frame payload back into the original content. */
export function parseSolo(payload: Uint8Array): SoloContent | null {
  try {
    const dv = new DataView(payload.buffer, payload.byteOffset, payload.byteLength)
    const metaLen = dv.getUint16(0, true)
    const meta = JSON.parse(textDecoder.decode(payload.subarray(2, 2 + metaLen)))
    const bytes = decompress(payload.subarray(2 + metaLen))
    return { kind: meta.kind, name: meta.name, mime: meta.mime, bytes }
  } catch {
    return null
  }
}

/**
 * Build the complete ordered frame list for one transfer.
 * `raw` is the original file/text bytes; it is compressed here.
 */
export function buildTransfer(
  raw: Uint8Array,
  meta: { kind: 'file' | 'text'; name: string; mime: string },
  opts: BuildOptions,
): BuiltTransfer {
  const zm = opts.zoneMap
  const capacity = zm ? capacityBytesZoned(zm) : capacityBytes(opts.spec)
  const rate = specRate(opts.spec)
  const usable = frameDataBytes(opts.spec, zm) - HEADER_BYTES - CRC_BYTES
  const chunkSize = Math.min(opts.chunkSize, usable)

  const comp = compress(raw)

  // A single static frame → whole matrix, no animation (QR-like).
  const solo = buildSolo(raw, meta, opts.spec, comp, zm)
  if (solo) {
    const manifest: TransferManifest = {
      v: 1, id: Math.floor(Math.random() * 0xffffffff) >>> 0,
      kind: meta.kind, name: meta.name, mime: meta.mime,
      total: raw.length, comp: comp.length, k: 1, chunk: comp.length,
      enc: opts.spec.enc, gridW: opts.spec.gridW, gridH: opts.spec.gridH, rate,
      ...(zm && opts.zoneRingWidth ? { zones: serializeZoneMap(opts.zoneRingWidth, zm.zones[0].enc) } : {}),
    }
    return { frames: [solo], manifest, capacity, dataFrameCount: 1, static: true }
  }

  const chunks = makeChunks(comp, chunkSize)
  const k = chunks.length

  const manifest: TransferManifest = {
    v: 1,
    id: Math.floor(Math.random() * 0xffffffff) >>> 0,
    kind: meta.kind,
    name: meta.name,
    mime: meta.mime,
    total: raw.length,
    comp: comp.length,
    k,
    chunk: chunkSize,
    enc: opts.spec.enc,
    gridW: opts.spec.gridW,
    gridH: opts.spec.gridH,
    rate,
    ...(zm && opts.zoneRingWidth ? { zones: serializeZoneMap(opts.zoneRingWidth, zm.zones[0].enc) } : {}),
  }

  const manifestFrames = encodeManifestFrames(manifest, capacity)
  // The receiver can't decode ANYTHING until it has the manifest (K, chunk size,
  // spec). With auto-detect the receiver often joins a second or two late — after
  // the leading copies — and at a realistic partial decode rate a sparse re-insert
  // makes "manifest seen" take painfully long. So re-insert it DENSELY (every 10)
  // and lead with several copies. Costs ~10% overhead for a much faster, more
  // reliable lock-on — the right trade now that metadata is the gating step.
  const manifestEvery = Math.max(4, opts.manifestEvery ?? 10)
  // MUST emit at least ~K distinct fountain frames or the transfer can never
  // complete (the receiver needs ~K distinct seeds). A larger pool also means
  // fewer repeat captures → faster collection. So always ensure the recommended
  // count regardless of any smaller requested value.
  const dataFrameCount = Math.max(opts.frameCount, recommendedFrameCount(k))

  // Lead with several manifest copies so a late-joining/auto-detecting receiver
  // grabs K and the chunk size within its first captures; then re-insert regularly.
  const frames: Uint8Array[] = [...manifestFrames, ...manifestFrames, ...manifestFrames, ...manifestFrames]
  for (let i = 0; i < dataFrameCount; i++) {
    const seed = i + 1 // seeds start at 1 (0 reserved for manifest)
    frames.push(packFrame(FRAME_TYPE_DATA, seed, fountainEncode(chunks, seed, chunkSize), capacity, rate))
    if ((i + 1) % manifestEvery === 0) frames.push(...manifestFrames)
  }

  return { frames, manifest, capacity, dataFrameCount, static: false }
}

/**
 * Distinct fountain frames to emit for K chunks. A pool ~2× K means most
 * captures are new (few repeats → faster), while staying bounded in memory.
 */
export function recommendedFrameCount(k: number): number {
  return Math.min(8000, Math.max(k + 30, Math.ceil(k * 2)))
}

/**
 * Turn a completed fountain reconstruction (k*chunk bytes) back into the
 * original file/text bytes: trim padding to the compressed length, inflate.
 */
export function finishTransfer(reconstructed: Uint8Array, manifest: TransferManifest): Uint8Array {
  const comp = reconstructed.subarray(0, manifest.comp)
  return decompress(comp)
}
