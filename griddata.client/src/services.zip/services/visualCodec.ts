// Visual codec: bytes ⇄ coloured cell grid, and the optical SOFT demodulator.
//
// Encodings (direct, no transform spreading):
//   bw       1 bit / cell   (black / white)          — fastest, needs clean reads
//   color8   3 bits / cell  (R,G,B each on/off)      — robust workhorse
//   color16  4 bits / cell  (R×2, G×4, B×2 levels)
//   color32  5 bits / cell  (R×4, G×4, B×2 levels)
//   color64  6 bits / cell  (R×4, G×4, B×4 levels)   — densest
//
// The receiver never takes a hard per-cell decision here. `softDemodLLR` emits a
// per-bit log-likelihood ratio that (a) un-mixes the display→camera colour
// cross-talk with a blind 3×3 MIMO estimate learned from calibration anchors,
// and (b) is SCALED by each cell's optical reliability (how in-focus / unsaturated
// that cell was). Those LLRs feed the LDPC belief-propagation decoder directly —
// the whole point of dropping Reed-Solomon and Hadamard was to keep this soft
// information instead of throwing it away at a threshold.

import { BARCODE_ROWS } from './metaBarcode'

export type Encoding = 'bw' | 'color8' | 'color16' | 'color32' | 'color64'

export interface EncodingSpec {
  enc: Encoding
  gridW: number // cells across (columns)
  gridH: number // cells down (rows)
  rate?: number // LDPC code rate (message/codeword). Higher = more payload, weaker
                // correction. Default 0.6; speed profiles raise it on clean channels.
}

/** Total cell count for a spec. */
export function gridCells(s: EncodingSpec): number { return s.gridW * s.gridH }

/** LDPC code rate for a spec (message bytes ÷ codeword bytes). */
export const DEFAULT_RATE = 0.6
export function specRate(s: EncodingSpec): number { return s.rate ?? DEFAULT_RATE }

export interface CellReadings {
  r: Float32Array
  g: Float32Array
  b: Float32Array
  lum: Float32Array
  /** Per-cell optical reliability in [0,1] (1 = crisp, 0 = blurred/saturated). */
  rel?: Float32Array
}

// ── bit packing ──
export function bytesToBits(data: Uint8Array): Uint8Array {
  const bits = new Uint8Array(data.length * 8)
  for (let i = 0; i < data.length; i++)
    for (let b = 7; b >= 0; b--) bits[i * 8 + (7 - b)] = (data[i] >> b) & 1
  return bits
}

export function bitsToBytes(bits: Uint8Array): Uint8Array {
  const data = new Uint8Array(Math.ceil(bits.length / 8))
  for (let i = 0; i < bits.length; i++)
    if (bits[i] === 1) data[Math.floor(i / 8)] |= 1 << (7 - (i % 8))
  return data
}

// ── Gray coding of the multi-level colour constellation ──
// Adjacent PHYSICAL levels (the ones the camera confuses) map to data words that
// differ by exactly one bit, so the dominant "read level ℓ as ℓ±1" error costs
// one bit, not two. Encode: data word d → physical level grayToBinary(d).
function binaryToGray(x: number): number { return x ^ (x >> 1) }
function grayToBinary(g: number): number { let b = 0; for (; g; g >>= 1) b ^= g; return b }

/** Bits carried per R,G,B channel for each encoding (null = single-level bw). */
export function colorChannelBits(enc: Encoding): [number, number, number] | null {
  switch (enc) {
    case 'color8': return [1, 1, 1]
    case 'color16': return [1, 2, 1]
    case 'color32': return [2, 2, 1]
    case 'color64': return [2, 2, 2]
    default: return null
  }
}

// ── Calibration anchors ──
// The first `count` cells of every colour frame display KNOWN colours. The
// receiver reads them to learn the display→camera colour transform per frame.
// They do double duty:
//   • single-channel level anchors  → per-channel level centres (residual gamma),
//   • black + single-channel MAX anchors → the 3×3 MIMO mixing matrix + offset
//     (channel cross-talk), see estimateMimo.
export interface ColorAnchor { pos: number; c: number; level: number; r: number; g: number; b: number }
export interface ColorCalibration {
  count: number
  anchors: ColorAnchor[]
  maxLevel: [number, number, number]
  cb: [number, number, number]
}

// ── Perceptual (ambient-aware) level placement ──
// The display emits light ∝ digital^γ, and room light + screen glare add a small
// constant in the LINEAR light domain. Both crush the DARK levels together
// (their emitted-light gap shrinks toward zero), and camera shot noise — which
// enters in that same linear domain — then confuses them. Spacing the levels so
// the EMITTED LIGHT (+ambient) is evenly spread pulls the dark levels apart.
// Endpoints are preserved (level 0 → digital 0, top level → digital 255), so this
// is a pure redistribution of the intermediate levels; the receiver relearns the
// centres from the anchors automatically, so encoder and demod stay consistent.
//
// Closed form: choose digital d(level) so the assumed observed value
//   pix = ((d^γ + a)/(1+a))^(1/γ)
// is evenly spaced. Camera-agnostic (uses only display γ + a mild ambient guess);
// measured ~50% BER reduction for color16/32/64 and robust to the real camera γ
// (2.0–2.4) and ambient (0–0.06). Tune LEVEL_GAMMA / LEVEL_AMBIENT per deployment.
export const LEVEL_GAMMA = 2.2    // display EOTF exponent
export const LEVEL_AMBIENT = 0.03 // assumed ambient light as a fraction of white

/** Map a channel level (0..maxLevel) to a display byte 0..255 with ambient-aware spacing. */
export function levelToByte(level: number, maxLevel: number): number {
  if (maxLevel <= 0) return 0
  const g = LEVEL_GAMMA, a = LEVEL_AMBIENT
  const pix0 = Math.pow(a / (1 + a), 1 / g)           // observed value of level 0
  const pix = pix0 + (1 - pix0) * (level / maxLevel)  // evenly spaced observed
  const light = Math.max(0, Math.pow(pix, g) * (1 + a) - a)
  const d = Math.pow(light, 1 / g)                    // invert display EOTF
  return Math.round(Math.min(1, Math.max(0, d)) * 255)
}

export function colorCalibration(enc: Encoding): ColorCalibration | null {
  const cb = colorChannelBits(enc)
  if (!cb || enc === 'color8') return null // color8 is 2-level/channel, thresholded (no anchors)
  const maxLevel: [number, number, number] = [(1 << cb[0]) - 1, (1 << cb[1]) - 1, (1 << cb[2]) - 1]
  const anchors: ColorAnchor[] = []
  let pos = 0
  for (let c = 0; c < 3; c++) {
    const L = maxLevel[c] + 1
    if (L <= 1) continue
    for (let l = 0; l < L; l++) {
      const rgb = [0, 0, 0]
      rgb[c] = levelToByte(l, maxLevel[c])
      anchors.push({ pos, c, level: l, r: rgb[0], g: rgb[1], b: rgb[2] })
      pos++
    }
  }
  return { count: pos, anchors, maxLevel, cb }
}

// ── capacity (row 0 reserved for barcode strip) ──
export function capacityBits(s: EncodingSpec): number {
  const n = gridCells(s) - s.gridW * BARCODE_ROWS
  const cb = colorChannelBits(s.enc)
  if (!cb) return n // bw
  if (s.enc === 'color8') return n * 3
  const cal = colorCalibration(s.enc)!
  return (n - cal.count) * (cb[0] + cb[1] + cb[2])
}
export function capacityBytes(s: EncodingSpec): number { return Math.floor(capacityBits(s) / 8) }

// ── encode: payload bytes → per-cell RGB (0..255 ×3) for the display ──
// Row 0 is left black (reserved for the barcode strip — caller overlays it).
export function encodeCellsRGB(payload: Uint8Array, s: EncodingSpec): Uint8Array {
  const n = gridCells(s)
  const bc = s.gridW * BARCODE_ROWS
  const out = new Uint8Array(n * 3)
  const bits = bytesToBits(payload)

  if (s.enc === 'bw') {
    for (let i = bc; i < n; i++) { const v = (bits[i - bc] ?? 0) ? 255 : 0; out[i * 3] = out[i * 3 + 1] = out[i * 3 + 2] = v }
    return out
  }
  if (s.enc === 'color8') {
    for (let i = bc; i < n; i++) {
      const b = (i - bc) * 3
      out[i * 3] = (bits[b] ?? 0) ? 255 : 0
      out[i * 3 + 1] = (bits[b + 1] ?? 0) ? 255 : 0
      out[i * 3 + 2] = (bits[b + 2] ?? 0) ? 255 : 0
    }
    return out
  }
  // Multi-level colour with leading calibration anchors (placed after barcode row).
  const cal = colorCalibration(s.enc)!
  const cb = cal.cb, max = cal.maxLevel
  for (const a of cal.anchors) { out[(bc + a.pos) * 3] = a.r; out[(bc + a.pos) * 3 + 1] = a.g; out[(bc + a.pos) * 3 + 2] = a.b }
  let o = 0
  for (let i = bc + cal.count; i < n; i++) {
    for (let c = 0; c < 3; c++) {
      let word = 0
      for (let j = 0; j < cb[c]; j++) word = (word << 1) | (bits[o++] ?? 0)
      const level = max[c] > 0 ? grayToBinary(word) : 0
      out[i * 3 + c] = levelToByte(level, max[c])
    }
  }
  return out
}

// ── 3×3 colour MIMO estimate ──
// Model: observed = A · emitted + off, where emitted ∈ [0,1]³ (per channel,
// normalised) and A captures channel cross-talk (R light bleeding into the G/B
// sensor buckets, white-balance gain, etc.). We solve A and off directly from
// anchors: the black anchor gives off; each single-channel MAX anchor gives one
// column of A. Returns the INVERSE (un-mix) matrix + offset, or null if the
// anchors are too degenerate to invert (caller falls back to per-channel k-means).
interface Mimo { inv: number[]; off: [number, number, number] }
function estimateMimo(cal: ColorCalibration, chan: [Float32Array, Float32Array, Float32Array], posOffset = 0): Mimo | null {
  // Offset = mean observed over all level-0 (black) anchors.
  const off: [number, number, number] = [0, 0, 0]
  let blacks = 0
  for (const a of cal.anchors) if (a.level === 0) { const p = a.pos + posOffset; off[0] += chan[0][p]; off[1] += chan[1][p]; off[2] += chan[2][p]; blacks++ }
  if (blacks === 0) return null
  off[0] /= blacks; off[1] /= blacks; off[2] /= blacks
  // Columns of A from each channel's MAX-level anchor (emitted = 1 on that channel).
  const A = [0, 0, 0, 0, 0, 0, 0, 0, 0] // row-major 3×3
  for (let c = 0; c < 3; c++) {
    const amax = cal.anchors.find(a => a.c === c && a.level === cal.maxLevel[c])
    if (!amax || cal.maxLevel[c] === 0) return null
    const ap = amax.pos + posOffset
    A[0 * 3 + c] = chan[0][ap] - off[0]
    A[1 * 3 + c] = chan[1][ap] - off[1]
    A[2 * 3 + c] = chan[2][ap] - off[2]
  }
  const inv = invert3(A)
  return inv ? { inv, off } : null
}

function invert3(m: number[]): number[] | null {
  const [a, b, c, d, e, f, g, h, i] = m
  const A = e * i - f * h, B = -(d * i - f * g), C = d * h - e * g
  const det = a * A + b * B + c * C
  if (Math.abs(det) < 1e-6) return null
  const id = 1 / det
  return [
    A * id, (c * h - b * i) * id, (b * f - c * e) * id,
    B * id, (a * i - c * g) * id, (c * d - a * f) * id,
    C * id, (b * g - a * h) * id, (a * e - b * d) * id,
  ]
}
function applyMimo(m: Mimo, r: number, g: number, b: number): [number, number, number] {
  const x = r - m.off[0], y = g - m.off[1], z = b - m.off[2]
  return [
    m.inv[0] * x + m.inv[1] * y + m.inv[2] * z,
    m.inv[3] * x + m.inv[4] * y + m.inv[5] * z,
    m.inv[6] * x + m.inv[7] * y + m.inv[8] * z,
  ]
}

/**
 * Soft-decision demodulation → per-frame-bit LLR (LLR > 0 favours bit 0), in the
 * exact bit order the encoder consumed, so `bytesToBits(frame)` lines up index
 * for index. Each cell's LLRs are scaled by its optical reliability rd.rel[i].
 * Length = capacityBytes*8.
 */
export interface SoftDemodOptions {
  mimo?: boolean        // apply the 3×3 colour cross-talk un-mixing (default true)
  reliability?: boolean // scale LLRs by per-cell optical reliability (default true)
}

export function softDemodLLR(rd: CellReadings, s: EncodingSpec, opts?: SoftDemodOptions): Float64Array {
  const useMimo = opts?.mimo !== false
  const useRel = opts?.reliability !== false
  const n = gridCells(s)
  const bc = s.gridW * BARCODE_ROWS
  const nBits = capacityBytes(s) * 8
  const rel = rd.rel
  const relOf = (i: number) => (useRel && rel ? rel[i] : 1)

  // bw / color8: 2-level per channel via an adaptive threshold (skip barcode row).
  if (s.enc === 'bw' || s.enc === 'color8') {
    const out = new Float64Array(nBits)
    const softCh = (v: Float32Array, put: (di: number, llr: number) => void) => {
      let mn = Infinity, mx = -Infinity
      for (let i = bc; i < n; i++) { if (v[i] < mn) mn = v[i]; if (v[i] > mx) mx = v[i] }
      const mid = (mn + mx) / 2, scale = 8 / Math.max(1, mx - mn)
      for (let i = bc; i < n; i++) {
        let l = (mid - v[i]) * scale * relOf(i)
        if (l > 20) l = 20; else if (l < -20) l = -20
        put(i - bc, l)
      }
    }
    if (s.enc === 'bw') softCh(rd.lum, (di, l) => { if (di < nBits) out[di] = l })
    else {
      softCh(rd.r, (di, l) => { const o = di * 3; if (o < nBits) out[o] = l })
      softCh(rd.g, (di, l) => { const o = di * 3 + 1; if (o < nBits) out[o] = l })
      softCh(rd.b, (di, l) => { const o = di * 3 + 2; if (o < nBits) out[o] = l })
    }
    return out
  }

  // Multi-level colour: un-mix cross-talk (MIMO), then per-channel soft levels.
  const cal = colorCalibration(s.enc)!
  const cb = cal.cb
  const chan: [Float32Array, Float32Array, Float32Array] = [rd.r, rd.g, rd.b]
  const mimo = useMimo ? estimateMimo(cal, chan, bc) : null

  // Un-mixed working values for every cell (skip barcode row; falls back to raw
  // channels if MIMO couldn't be estimated).
  const um: [Float32Array, Float32Array, Float32Array] = [new Float32Array(n), new Float32Array(n), new Float32Array(n)]
  for (let i = bc; i < n; i++) {
    if (mimo) { const [er, eg, eb] = applyMimo(mimo, rd.r[i], rd.g[i], rd.b[i]); um[0][i] = er; um[1][i] = eg; um[2][i] = eb }
    else { um[0][i] = rd.r[i]; um[1][i] = rd.g[i]; um[2][i] = rd.b[i] }
  }

  // Per-channel level centres, learned from the (un-mixed) anchors; k-means fallback.
  const centers: number[][] = [[], [], []]
  for (const a of cal.anchors) centers[a.c][a.level] = um[a.c][a.pos + bc]
  for (let c = 0; c < 3; c++) {
    const L = 1 << cb[c]
    if (L === 1) continue
    let ok = centers[c].length === L
    for (let k = 1; k < L && ok; k++) if (!(centers[c][k] - centers[c][k - 1] > 1e-3)) ok = false
    if (!ok) centers[c] = kmeans1d(um[c], n, L, bc)
  }

  const per = cb[0] + cb[1] + cb[2]
  const dataStart = bc + cal.count
  const dataN = n - dataStart
  const out = new Float64Array(nBits)
  for (let c = 0; c < 3; c++) {
    const L = 1 << cb[c]
    if (L === 1) continue
    const ctr = centers[c]
    let gap = 0
    for (let k = 1; k < L; k++) gap += Math.abs(ctr[k] - ctr[k - 1])
    gap = Math.max(1e-3, gap / (L - 1))
    const sigma = gap * 0.35
    const scale = 1 / (2 * sigma * sigma)
    const chanOffset = c === 0 ? 0 : c === 1 ? cb[0] : cb[0] + cb[1]
    for (let d = 0; d < dataN; d++) {
      const cellRel = relOf(dataStart + d)
      const v = um[c][dataStart + d]
      for (let t = 0; t < cb[c]; t++) {
        const wbit = cb[c] - 1 - t
        let d0 = Infinity, d1 = Infinity
        for (let level = 0; level < L; level++) {
          const word = binaryToGray(level)
          const dist = v - ctr[level], dd = dist * dist
          if ((word >> wbit) & 1) { if (dd < d1) d1 = dd } else { if (dd < d0) d0 = dd }
        }
        const o = d * per + chanOffset + t
        if (o < nBits) {
          let llr = (d1 - d0) * scale * cellRel
          if (llr > 40) llr = 40; else if (llr < -40) llr = -40
          out[o] = llr
        }
      }
    }
  }
  return out
}

// ══════════════════════════════════════════════════════════════════════════════
// Zone-aware encoding / decoding
// ══════════════════════════════════════════════════════════════════════════════
// When adaptive spatial coding is active, each cell uses its zone's encoding.
// Calibration anchors use the densest encoding and are placed at cell 0..cal-1.
// The LDPC codeword / interleaving operates on the flat bitstream; these
// functions translate between that bitstream and the variable-bits-per-cell grid.

import { type ZoneMap, cellZoneEnc, bitsPerCellEnc, isMultiZone } from './adaptiveZones'
export type { ZoneMap }

/** Data capacity in bits for a zone map (excludes barcode row and calibration anchors). */
export function capacityBitsZoned(zm: ZoneMap): number {
  const n = zm.gridW * zm.gridH
  const bc = zm.gridW * BARCODE_ROWS
  const densest = zm.zones[0]?.enc ?? 'color8'
  const cal = colorCalibration(densest)
  const anchorCount = cal?.count ?? 0
  let total = 0
  for (let i = bc + anchorCount; i < n; i++) total += bitsPerCellEnc(cellZoneEnc(zm, i - bc))
  return total
}
export function capacityBytesZoned(zm: ZoneMap): number {
  return Math.floor(capacityBitsZoned(zm) / 8)
}

/**
 * Encode payload bits into per-cell RGB using zone-aware variable encoding.
 * Calibration anchors for the densest zone are placed at the first cells.
 */
export function encodeCellsRGBZoned(payload: Uint8Array, zm: ZoneMap): Uint8Array {
  if (!isMultiZone(zm)) return encodeCellsRGB(payload, { enc: zm.zones[0].enc, gridW: zm.gridW, gridH: zm.gridH })
  const { gridW, gridH } = zm
  const n = gridW * gridH
  const bc = gridW * BARCODE_ROWS
  const out = new Uint8Array(n * 3)
  const bits = bytesToBits(payload)

  const densest = zm.zones[0].enc
  const cal = colorCalibration(densest)
  const anchorCount = cal?.count ?? 0
  if (cal) for (const a of cal.anchors) { out[(bc + a.pos) * 3] = a.r; out[(bc + a.pos) * 3 + 1] = a.g; out[(bc + a.pos) * 3 + 2] = a.b }

  let bo = 0
  for (let i = bc + anchorCount; i < n; i++) {
    const enc = cellZoneEnc(zm, i - bc)
    if (enc === 'bw') {
      const v = (bits[bo] ?? 0) ? 255 : 0
      out[i * 3] = out[i * 3 + 1] = out[i * 3 + 2] = v
      bo++
    } else if (enc === 'color8') {
      out[i * 3]     = (bits[bo]     ?? 0) ? 255 : 0
      out[i * 3 + 1] = (bits[bo + 1] ?? 0) ? 255 : 0
      out[i * 3 + 2] = (bits[bo + 2] ?? 0) ? 255 : 0
      bo += 3
    } else {
      const cb = colorChannelBits(enc)!
      const ml: [number, number, number] = [(1 << cb[0]) - 1, (1 << cb[1]) - 1, (1 << cb[2]) - 1]
      for (let c = 0; c < 3; c++) {
        let word = 0
        for (let j = 0; j < cb[c]; j++) word = (word << 1) | (bits[bo++] ?? 0)
        out[i * 3 + c] = levelToByte(ml[c] > 0 ? grayToBinary(word) : 0, ml[c])
      }
    }
  }
  return out
}

/**
 * Zone-aware soft demodulation → per-data-bit LLR, in the same bit order as
 * encodeCellsRGBZoned consumed them. The MIMO matrix is estimated from the
 * densest zone's calibration anchors (the display→camera colour transform is
 * global); per-channel level centres for each encoding are derived from k-means
 * over that encoding's cells.
 */
export function softDemodLLRZoned(
  rd: CellReadings, zm: ZoneMap, opts?: SoftDemodOptions
): Float64Array {
  if (!isMultiZone(zm)) return softDemodLLR(rd, { enc: zm.zones[0].enc, gridW: zm.gridW, gridH: zm.gridH }, opts)
  const useMimo = opts?.mimo !== false
  const useRel  = opts?.reliability !== false
  const { gridW, gridH } = zm
  const n = gridW * gridH
  const bc = gridW * BARCODE_ROWS
  const rel = rd.rel
  const relOf = (i: number) => (useRel && rel ? rel[i] : 1)

  const nBits = capacityBytesZoned(zm) * 8
  const out = new Float64Array(nBits)

  const densest = zm.zones[0].enc
  const cal = colorCalibration(densest)
  const anchorCount = cal?.count ?? 0
  const chan: [Float32Array, Float32Array, Float32Array] = [rd.r, rd.g, rd.b]
  const mimo = (useMimo && cal) ? estimateMimo(cal, chan, bc) : null

  // Un-mix ALL cells (skip barcode row 0)
  const um: [Float32Array, Float32Array, Float32Array] = [new Float32Array(n), new Float32Array(n), new Float32Array(n)]
  for (let i = bc; i < n; i++) {
    if (mimo) { const [er, eg, eb] = applyMimo(mimo, rd.r[i], rd.g[i], rd.b[i]); um[0][i] = er; um[1][i] = eg; um[2][i] = eb }
    else { um[0][i] = rd.r[i]; um[1][i] = rd.g[i]; um[2][i] = rd.b[i] }
  }

  // Global thresholds for bw (luminance) and color8 (per-channel) — skip barcode row
  let lumMn = Infinity, lumMx = -Infinity
  for (let i = bc; i < n; i++) { if (rd.lum[i] < lumMn) lumMn = rd.lum[i]; if (rd.lum[i] > lumMx) lumMx = rd.lum[i] }
  const lumMid = (lumMn + lumMx) / 2, lumSc = 8 / Math.max(1, lumMx - lumMn)
  const chMid = [0, 0, 0], chSc = [0, 0, 0]
  for (let c = 0; c < 3; c++) {
    let mn = Infinity, mx = -Infinity
    for (let i = bc; i < n; i++) { if (chan[c][i] < mn) mn = chan[c][i]; if (chan[c][i] > mx) mx = chan[c][i] }
    chMid[c] = (mn + mx) / 2; chSc[c] = 8 / Math.max(1, mx - mn)
  }

  // Per-encoding level centres for multi-level zones via k-means
  const mlCenters = new Map<Encoding, number[][]>()
  const encCellSets = new Map<Encoding, number[]>()
  for (let i = bc + anchorCount; i < n; i++) {
    const enc = cellZoneEnc(zm, i - bc)
    if (enc !== 'bw' && enc !== 'color8') {
      let arr = encCellSets.get(enc)
      if (!arr) { arr = []; encCellSets.set(enc, arr) }
      arr.push(i)
    }
  }
  for (const [enc, cells] of encCellSets) {
    const cb = colorChannelBits(enc)!
    const cen: number[][] = [[], [], []]
    if (cal && enc === densest) for (const a of cal.anchors) cen[a.c][a.level] = um[a.c][bc + a.pos]
    for (let c = 0; c < 3; c++) {
      const L = 1 << cb[c]
      if (L <= 1) continue
      let ok = cen[c].length === L
      for (let k = 1; k < L && ok; k++) if (!(cen[c][k] - cen[c][k - 1] > 1e-3)) ok = false
      if (!ok) {
        const vals = new Float32Array(cells.length)
        for (let j = 0; j < cells.length; j++) vals[j] = um[c][cells[j]]
        cen[c] = kmeans1d(vals, vals.length, L)
      }
    }
    mlCenters.set(enc, cen)
  }

  // Produce LLRs per data cell
  let bo = 0
  for (let i = bc + anchorCount; i < n; i++) {
    const enc = cellZoneEnc(zm, i - bc)
    const cr = relOf(i)
    if (enc === 'bw') {
      let l = (lumMid - rd.lum[i]) * lumSc * cr
      if (l > 20) l = 20; else if (l < -20) l = -20
      if (bo < nBits) out[bo] = l
      bo++
    } else if (enc === 'color8') {
      for (let c = 0; c < 3; c++) {
        let l = (chMid[c] - chan[c][i]) * chSc[c] * cr
        if (l > 20) l = 20; else if (l < -20) l = -20
        if (bo < nBits) out[bo] = l
        bo++
      }
    } else {
      const cb = colorChannelBits(enc)!
      const cen = mlCenters.get(enc)!
      for (let c = 0; c < 3; c++) {
        const L = 1 << cb[c]
        if (L <= 1) continue
        const ctr = cen[c]
        let gap = 0
        for (let k = 1; k < L; k++) gap += Math.abs(ctr[k] - ctr[k - 1])
        gap = Math.max(1e-3, gap / (L - 1))
        const sigma = gap * 0.35, scale = 1 / (2 * sigma * sigma)
        const v = um[c][i]
        for (let t = 0; t < cb[c]; t++) {
          const wbit = cb[c] - 1 - t
          let d0 = Infinity, d1 = Infinity
          for (let level = 0; level < L; level++) {
            const word = binaryToGray(level)
            const dist = v - ctr[level], dd = dist * dist
            if ((word >> wbit) & 1) { if (dd < d1) d1 = dd } else { if (dd < d0) d0 = dd }
          }
          if (bo < nBits) {
            let llr = (d1 - d0) * scale * cr
            if (llr > 40) llr = 40; else if (llr < -40) llr = -40
            out[bo] = llr
          }
          bo++
        }
      }
    }
  }
  return out
}

/**
 * 1-D k-means over the first `n` samples of `v` into `L` clusters. Centres are
 * seeded evenly across the observed range and returned ascending, so a sample's
 * nearest-centre index is directly its quantised level. Invariant to any
 * monotonic gain/offset the camera applies — the k-means fallback for when the
 * anchors themselves come back unusable.
 */
function kmeans1d(v: ArrayLike<number>, n: number, L: number, startIdx = 0): number[] {
  let mn = Infinity, mx = -Infinity
  for (let i = startIdx; i < n; i++) { const x = v[i]; if (x < mn) mn = x; if (x > mx) mx = x }
  if (mx - mn < 1e-6) return Array.from({ length: L }, () => mn)
  const cen = Array.from({ length: L }, (_, k) => mn + (mx - mn) * k / (L - 1))
  const sum = new Float64Array(L), cnt = new Int32Array(L)
  for (let it = 0; it < 12; it++) {
    sum.fill(0); cnt.fill(0)
    for (let i = startIdx; i < n; i++) {
      const x = v[i]
      let bk = 0, bd = Infinity
      for (let k = 0; k < L; k++) { const d = Math.abs(x - cen[k]); if (d < bd) { bd = d; bk = k } }
      sum[bk] += x; cnt[bk]++
    }
    for (let k = 0; k < L; k++) if (cnt[k]) cen[k] = sum[k] / cnt[k]
    cen.sort((a, b) => a - b)
  }
  return cen
}
