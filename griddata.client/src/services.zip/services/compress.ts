import { deflate, inflate } from 'pako'

/** Deflate compression. Mirrors the server's GZip/deflate stage. */
export function compress(data: Uint8Array): Uint8Array {
  return deflate(data)
}

export function decompress(data: Uint8Array): Uint8Array {
  return inflate(data)
}
